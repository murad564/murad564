const imageSectionConfig = {
  props: {
    content: {
      url: 'https://i.imgflip.com/65efzo.gif',
    },

    styles: {
      align: 'center',
      height: 200,
      float: 'none',
    },
  },
};

export { imageSectionConfig };
