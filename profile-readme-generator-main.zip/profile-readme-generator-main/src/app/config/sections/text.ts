const textSectionConfig = {
  props: {
    content: {
      text: 'Hello World!!',
      as: 'p',
    },

    styles: {
      align: 'left',
    },
  },
};

export { textSectionConfig };
