const activitiesSectionConfig = {
  props: {
    content: {
      type: 'medium',
      limit: 4,
    },

    styles: {
      align: 'center',
    },
  },
};

export { activitiesSectionConfig };
