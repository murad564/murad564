const snakeSectionConfig = {
  props: {
    styles: {},
  },
};

export { snakeSectionConfig };
