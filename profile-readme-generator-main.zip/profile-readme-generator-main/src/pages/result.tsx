import { ResultTemplate } from 'templates';

const Result = () => <ResultTemplate />;

export default Result;
