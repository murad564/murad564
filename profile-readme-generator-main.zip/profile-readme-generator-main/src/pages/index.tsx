import { CanvasTemplate } from 'templates';

const Home = () => {
  return <CanvasTemplate />;
};

export default Home;
