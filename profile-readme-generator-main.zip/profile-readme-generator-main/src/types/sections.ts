export enum Sections {
  TEXT = 'text',
  STATS = 'stats',
  TECHS = 'techs',
  PROFILE_VIEWS = 'profile-views',
  IMAGE = 'image',
  SOCIALS = 'socials',
  SNAKE = 'snake',
  ACTIVITIES = 'activities',
  MUSIC = 'music',
}
