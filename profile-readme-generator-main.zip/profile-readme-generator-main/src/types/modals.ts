export enum Modals {
  IMPROVE_SKILLS = 'improve-skills',
  SHARE = 'share',
}
