export enum ContextMenus {
  SECTION = 'contextmenu.section',
}
