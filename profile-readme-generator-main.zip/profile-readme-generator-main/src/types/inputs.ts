export enum Inputs {
  TEXT = 'input.text',
  SWITCH = 'input.switch',
  SELECT = 'input.select',
}
