export enum HTTPMethods {
  GET = 'GET',
  PUT = 'PUT',
}
