export type Settings = {
  user: Record<string, unknown>;
};
