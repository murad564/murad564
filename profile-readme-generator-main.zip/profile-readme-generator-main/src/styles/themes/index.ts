export { defaultTheme as theme } from './default';
