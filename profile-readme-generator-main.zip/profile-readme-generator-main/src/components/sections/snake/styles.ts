import styled from 'styled-components';

export const Container = styled.div`
  display: grid;
  place-items: center;
`;

export const Image = styled.img`
  width: 100%;
`;
