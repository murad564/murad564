import * as S from './styled';

const DefaultEditPanel = () => {
  return <S.Container />;
};

export { DefaultEditPanel };
