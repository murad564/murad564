const info_links = [
  {
    label: 'Connect Spotify account',
    link: 'https://spotify-recently-played-readme.vercel.app',
  },
  {
    label: 'More info',
    link: 'https://github.com/JeffreyCA/spotify-recently-played-readme#getting-started',
  },
];

export { info_links };
